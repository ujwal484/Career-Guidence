import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { motion } from "framer-motion";
import { ArrowRight, Compass, Clock, UserX, Gift } from "lucide-react";
import { useNavigate } from "react-router";

export default function Landing() {
  const { isLoading, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const handleGetStarted = () => {
    // Redirect to the career recommendation form
    window.location.href = '/form.html';
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-800"
    >
      {/* Navigation */}
      <nav className="p-4 flex justify-end">
        {isAuthenticated ? (
          <Button
            variant="ghost"
            className="text-white hover:text-blue-200"
            onClick={() => navigate("/auth")}
          >
            Profile
          </Button>
        ) : (
          <Button
            variant="ghost"
            className="text-white hover:text-blue-200"
            onClick={() => navigate("/auth")}
          >
            Sign In
          </Button>
        )}
      </nav>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="max-w-4xl mx-auto text-center">
          {/* Glass Card */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="bg-white/10 backdrop-blur-lg rounded-3xl border border-white/20 p-8 md:p-12 shadow-2xl"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="mb-8"
            >
              <Compass className="w-16 h-16 text-white mx-auto mb-6 animate-pulse" />
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
                Discover Your Best Career Path in Seconds
              </h1>
              <p className="text-xl md:text-2xl text-blue-100 mb-8">
                Find your career path in 10 seconds – No signup, Free!
              </p>
            </motion.div>

            <motion.div
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="space-y-6"
            >
              <Button
                onClick={handleGetStarted}
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white text-xl px-8 py-4 rounded-full transform hover:scale-105 transition-all duration-300 shadow-lg"
              >
                <ArrowRight className="mr-2 h-5 w-5" />
                Get Started
              </Button>

              <div className="flex justify-center space-x-8 mt-8 text-blue-100">
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ duration: 0.5, delay: 0.8 }}
                  className="text-center"
                >
                  <Clock className="w-8 h-8 mx-auto mb-2" />
                  <p className="text-sm">10 Seconds</p>
                </motion.div>
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ duration: 0.5, delay: 0.9 }}
                  className="text-center"
                >
                  <UserX className="w-8 h-8 mx-auto mb-2" />
                  <p className="text-sm">No Signup</p>
                </motion.div>
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ duration: 0.5, delay: 1.0 }}
                  className="text-center"
                >
                  <Gift className="w-8 h-8 mx-auto mb-2" />
                  <p className="text-sm">100% Free</p>
                </motion.div>
              </div>
            </motion.div>
          </motion.div>

          {/* Features Section */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 1.2 }}
            className="mt-16 grid md:grid-cols-3 gap-8"
          >
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
              <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Compass className="w-6 h-6 text-blue-300" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Smart Matching</h3>
              <p className="text-blue-200">AI-powered career recommendations based on your unique skills and interests</p>
            </div>
            
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
              <div className="w-12 h-12 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <ArrowRight className="w-6 h-6 text-purple-300" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Clear Roadmap</h3>
              <p className="text-blue-200">Step-by-step guidance to achieve your career goals with actionable plans</p>
            </div>
            
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
              <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Gift className="w-6 h-6 text-green-300" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Free Resources</h3>
              <p className="text-blue-200">Curated learning materials and tools to kickstart your career journey</p>
            </div>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}