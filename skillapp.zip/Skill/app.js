// Career Recommendation App - Main JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Check which page we're on
    const currentPath = window.location.pathname;
    const pageName = currentPath.split('/').pop();
    
    // Initialize page-specific functionality
    if (pageName === 'form.html') {
        initFormPage();
    } else if (pageName === 'results.html') {
        initResultsPage();
    }
    
    // Check API status on all pages
    checkApiStatus();
});

// API Configuration
const API_BASE_URL = 'http://127.0.0.1:8000';
const API_ENDPOINTS = {
    status: '/',
    health: '/health',
    recommend: '/recommend'
};

// Check if the API is available
async function checkApiStatus() {
    try {
        const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.health}`);
        if (!response.ok) {
            console.warn('API health check failed:', response.status);
        } else {
            console.log('API is available');
        }
    } catch (error) {
        console.error('API is not available:', error);
    }
}

// Form Page Functionality
function initFormPage() {
    const form = document.getElementById('careerForm');
    const skillsInput = document.getElementById('skills');
    const interestsInput = document.getElementById('interests');
    const skillTags = document.getElementById('skillTags');
    const interestTags = document.getElementById('interestTags');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const errorMessage = document.getElementById('errorMessage');
    const errorText = document.getElementById('errorText');
    
    // Initialize tag inputs
    initTagInput(skillsInput, skillTags);
    initTagInput(interestsInput, interestTags);
    
    // Form submission
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        // Get all skill and interest tags
        const skills = Array.from(skillTags.querySelectorAll('.tag')).map(tag => tag.dataset.value);
        const interests = Array.from(interestTags.querySelectorAll('.tag')).map(tag => tag.dataset.value);
        
        // Validate inputs
        if (skills.length === 0 || interests.length === 0) {
            showError('Please enter at least one skill and one interest.');
            return;
        }
        
        // Show loading spinner
        loadingSpinner.classList.remove('hidden');
        errorMessage.classList.add('hidden');
        
        try {
            // Call the API
            const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.recommend}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ skills, interests })
            });
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status}`);
            }
            
            const data = await response.json();
            
            // Store the results in sessionStorage
            sessionStorage.setItem('careerRecommendation', JSON.stringify(data));
            
            // Redirect to results page
            window.location.href = 'results.html';
            
        } catch (error) {
            console.error('Error fetching recommendations:', error);
            showError('Unable to connect to the recommendation service. Please try again later.');
            loadingSpinner.classList.add('hidden');
        }
    });
    
    function showError(message) {
        errorText.textContent = message;
        errorMessage.classList.remove('hidden');
        setTimeout(() => {
            errorMessage.classList.add('fade-in');
        }, 10);
    }
}

// Initialize tag input functionality
function initTagInput(input, tagContainer) {
    // Add tag when comma or Enter is pressed
    input.addEventListener('keydown', function(e) {
        if (e.key === ',' || e.key === 'Enter') {
            e.preventDefault();
            addTag(input.value.trim());
        }
    });
    
    // Add tag when input loses focus
    input.addEventListener('blur', function() {
        if (input.value.trim()) {
            addTag(input.value.trim());
        }
    });
    
    function addTag(text) {
        // Skip if empty or just a comma
        if (!text || text === ',') return;
        
        // Remove trailing comma if present
        if (text.endsWith(',')) {
            text = text.slice(0, -1).trim();
        }
        
        // Split by comma and add multiple tags
        const tags = text.split(',').map(t => t.trim()).filter(t => t);
        
        tags.forEach(tagText => {
            // Create tag element
            const tag = document.createElement('div');
            tag.className = 'tag';
            tag.dataset.value = tagText;
            
            // Add tag content
            tag.innerHTML = `
                <span>${tagText}</span>
                <span class="tag-close">×</span>
            `;
            
            // Add remove functionality
            tag.querySelector('.tag-close').addEventListener('click', function() {
                tag.remove();
            });
            
            // Add to container
            tagContainer.appendChild(tag);
        });
        
        // Clear input
        input.value = '';
    }
}

// Results Page Functionality
function initResultsPage() {
    const resultsContainer = document.getElementById('resultsContainer');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const errorMessage = document.getElementById('errorMessage');
    const errorText = document.getElementById('errorText');
    
    // Try to get results from sessionStorage
    const recommendationData = sessionStorage.getItem('careerRecommendation');
    
    if (!recommendationData) {
        // If no data in sessionStorage, show error and redirect back to form
        showError('No recommendation data found. Please fill out the form again.');
        setTimeout(() => {
            window.location.href = 'form.html';
        }, 3000);
        return;
    }
    
    try {
        // Parse the data
        const recommendation = JSON.parse(recommendationData);
        
        // Hide loading spinner
        loadingSpinner.classList.add('hidden');
        
        // Show results container with animation
        resultsContainer.classList.remove('hidden');
        setTimeout(() => {
            resultsContainer.classList.add('fade-in');
        }, 10);
        
        // Populate the results
        populateCareerInfo(recommendation);
        populateRoadmap(recommendation);
        populateResources(recommendation);
        
    } catch (error) {
        console.error('Error displaying results:', error);
        showError('Error displaying recommendations. Please try again.');
    }
    
    function showError(message) {
        loadingSpinner.classList.add('hidden');
        errorText.textContent = message;
        errorMessage.classList.remove('hidden');
    }
}

// Populate career information
function populateCareerInfo(data) {
    const careerTitle = document.getElementById('careerTitle');
    const careerDescription = document.getElementById('careerDescription');
    
    careerTitle.textContent = data.career || 'Career Path Not Found';
    careerDescription.textContent = data.description || 'No description available for this career path.';
}

// Populate roadmap
function populateRoadmap(data) {
    const roadmapContainer = document.getElementById('roadmapContainer');
    
    if (!data.roadmap || !Array.isArray(data.roadmap) || data.roadmap.length === 0) {
        roadmapContainer.innerHTML = '<p class="text-white opacity-80">No roadmap available for this career path.</p>';
        return;
    }
    
    // Clear container
    roadmapContainer.innerHTML = '';
    
    // Add each roadmap step
    data.roadmap.forEach((step, index) => {
        const stepElement = document.createElement('div');
        stepElement.className = 'roadmap-item';
        
        stepElement.innerHTML = `
            <h4 class="text-white font-bold">${index + 1}. ${step.title || 'Step ' + (index + 1)}</h4>
            <p class="text-white opacity-80">${step.description || ''}</p>
        `;
        
        roadmapContainer.appendChild(stepElement);
    });
}

// Populate resources
function populateResources(data) {
    const resourcesContainer = document.getElementById('resourcesContainer');
    
    if (!data.resources || !Array.isArray(data.resources) || data.resources.length === 0) {
        resourcesContainer.innerHTML = '<p class="text-white opacity-80">No resources available for this career path.</p>';
        return;
    }
    
    // Clear container
    resourcesContainer.innerHTML = '';
    
    // Map resource types to Font Awesome icons
    const resourceIcons = {
        'book': 'fa-book',
        'video': 'fa-video',
        'course': 'fa-graduation-cap',
        'website': 'fa-globe',
        'tool': 'fa-tools',
        'community': 'fa-users',
        'default': 'fa-link'
    };
    
    // Add each resource
    data.resources.forEach(resource => {
        const resourceElement = document.createElement('a');
        resourceElement.href = resource.url || '#';
        resourceElement.target = '_blank';
        resourceElement.rel = 'noopener noreferrer';
        resourceElement.className = 'resource-card';
        
        // Determine icon
        const iconClass = resourceIcons[resource.type?.toLowerCase()] || resourceIcons.default;
        
        resourceElement.innerHTML = `
            <div class="resource-icon">
                <i class="fas ${iconClass}"></i>
            </div>
            <div>
                <h4 class="text-white font-bold">${resource.title || 'Resource'}</h4>
                <p class="text-white opacity-70 text-sm">${resource.description || ''}</p>
            </div>
        `;
        
        resourcesContainer.appendChild(resourceElement);
    });
}