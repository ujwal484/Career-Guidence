from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
import json, pathlib

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:8080", "http://localhost:8080"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class RecommendIn(BaseModel):
    skills: List[str]
    interests: List[str]

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/recommend")
def recommend(payload: RecommendIn):
    data_path = pathlib.Path(__file__).parent / "careers.json"
    data = json.loads(data_path.read_text())
    return data
